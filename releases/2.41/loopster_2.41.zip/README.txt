DJBB Loopster Update Instructions
==================================

1. While holding the BOOT button (small button near the lower right corner of the screen),
   plug the Loopster into your computer. It should mount as a drive called "RPI-RP2".

2. Drag the "loopster.uf2" file onto the RPI-RP2 drive.
   The device will reboot and remount as "CIRCUITPY" or "LOOPSTER".
   If it doesn't appear after ~30 seconds, just continue to the next step.

3. Unplug the Loopster, then hold the FN button and plug it back in.

4. Delete all existing files on the device.

4. Copy the entire contents of the "files" folder to the now-empty drive:
   - boot.py
   - code.py
   - presets.json
   - useraddons.py
   - font5x8.bin
   - lib/ (entire folder)
   - ... (all other files / folders in this folder)

5. Safely eject the drive. Your Loopster is updated!

For more info, visit: https://github.com/derrickthomin/DJBB-Loopster
